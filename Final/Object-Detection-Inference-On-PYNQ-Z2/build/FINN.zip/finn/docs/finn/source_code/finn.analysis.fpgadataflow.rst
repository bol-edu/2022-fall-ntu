Analysis - fpgadataflow
***********************

Analysis Passes (fpgadataflow)
==============================

finn.analysis.fpgadataflow.dataflow\_performance
------------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.dataflow_performance
   :members:
   :undoc-members:
   :show-inheritance:


finn.analysis.fpgadataflow.exp\_cycles\_per\_layer
---------------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.exp_cycles_per_layer
   :members:
   :undoc-members:
   :show-inheritance:


finn.analysis.fpgadataflow.floorplan\_params
--------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.floorplan_params
   :members:
   :undoc-members:
   :show-inheritance:

finn.analysis.fpgadataflow.hls\_synth\_res\_estimation
-------------------------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.hls_synth_res_estimation
   :members:
   :undoc-members:
   :show-inheritance:

 finn.analysis.fpgadataflow.op\_and\_param\_counts
 --------------------------------------------------

 .. automodule:: finn.analysis.fpgadataflow.op_and_param_counts
    :members:
    :undoc-members:
    :show-inheritance:

finn.analysis.fpgadataflow.post\_synth\_res
--------------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.post_synth_res
   :members:
   :undoc-members:
   :show-inheritance:

finn.analysis.fpgadataflow.res\_estimation
-------------------------------------------------

.. automodule:: finn.analysis.fpgadataflow.res_estimation
   :members:
   :undoc-members:
   :show-inheritance:
