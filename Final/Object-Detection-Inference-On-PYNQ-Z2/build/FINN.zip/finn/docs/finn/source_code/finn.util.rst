****
Util
****

Utility Modules
===============

qonnx.util.basic
----------------------

.. automodule:: qonnx.util.basic
   :members:
   :undoc-members:
   :show-inheritance:


qonnx.util.config
--------------------

.. automodule:: qonnx.util.config
  :members:
  :undoc-members:
  :show-inheritance:

finn.util.basic
----------------------

.. automodule:: finn.util.basic
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.create
------------------

.. automodule:: finn.util.create
  :members:
  :undoc-members:
  :show-inheritance:



finn.util.data\_packing
------------------------------

.. automodule:: finn.util.data_packing
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.fpgadataflow
-----------------------------

.. automodule:: finn.util.fpgadataflow
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.gdrive
-----------------------------

.. automodule:: finn.util.gdrive
  :members:
  :undoc-members:
  :show-inheritance:

finn.util.imagenet
-----------------------------

.. automodule:: finn.util.imagenet
  :members:
  :undoc-members:
  :show-inheritance:

qonnx.util.onnx
---------------------

.. automodule:: qonnx.util.onnx
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.platforms
--------------------

.. automodule:: finn.util.platforms
   :members:
   :undoc-members:
   :show-inheritance:


finn.util.pytorch
------------------

.. automodule:: finn.util.pytorch
 :members:
 :undoc-members:
 :show-inheritance:


finn.util.pyverilator
---------------------

.. automodule:: finn.util.pyverilator
  :members:
  :undoc-members:
  :show-inheritance:


finn.util.test
---------------------

.. automodule:: finn.util.test
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.vcd
------------------------------

.. automodule:: finn.util.vcd
  :members:
  :undoc-members:
  :show-inheritance:

finn.util.visualization
------------------------------

.. automodule:: finn.util.visualization
   :members:
   :undoc-members:
   :show-inheritance:

finn.util.vivado
------------------------------

.. automodule:: finn.util.vivado
  :members:
  :undoc-members:
  :show-inheritance:
